/**
 * Filtra las tarjetas de torneo de la grilla según el texto escrito
 * en el buscador, comparando contra el nombre guardado en data-name.
 * @method buscarTorneo
 * @param {Event} evento - Evento "input" disparado por el buscador
 * @return {void}
 */
const buscarTorneo = (evento) => {
  const termino = evento.target.value.toLowerCase();
  document.querySelectorAll('.tournament-card').forEach((tarjeta) => {
    const nombre = tarjeta.dataset.name || '';
    tarjeta.classList.toggle('hidden', !nombre.includes(termino));
  });
};

/**
 * Abre el overlay con el detalle del torneo, tomando los datos desde
 * los atributos data- de la tarjeta y la imagen que fue clickeada.
 * @method mostrarDetalle
 * @param {HTMLElement} tarjeta - Tarjeta de torneo seleccionada
 * @return {void}
 */
const mostrarDetalle = (tarjeta) => {
  const imagen = tarjeta.querySelector('img');

  document.getElementById('modal-nombre').textContent = tarjeta.dataset.title;
  document.getElementById('modal-nivel').textContent = tarjeta.dataset.nivel;
  document.getElementById('modal-desc').textContent = tarjeta.dataset.desc;
  document.getElementById('modal-fecha').textContent = tarjeta.dataset.fecha;
  document.getElementById('modal-ubicacion').textContent = tarjeta.dataset.ubicacion;
  document.getElementById('modal-jugadores').textContent = tarjeta.dataset.jugadores;
  document.getElementById('modal-img').src = imagen.src;
  document.getElementById('modal-img').alt = imagen.alt;

  document.getElementById('overlay').classList.add('show');
};

/**
 * Cierra el overlay de detalle del torneo.
 * @method cerrarDetalle
 * @return {void}
 */
const cerrarDetalle = () => {
  document.getElementById('overlay').classList.remove('show');
};

/**
 * Marca como seleccionado el formato de torneo elegido por el usuario
 * y refleja el cambio en el resumen del formulario.
 * @method seleccionarFormato
 * @param {HTMLElement} opcion - Opción de formato clickeada
 * @return {void}
 */
const seleccionarFormato = (opcion) => {
  document.querySelectorAll('.choice').forEach((c) => c.classList.remove('selected'));
  opcion.classList.add('selected');
  document.getElementById('resumen-formato').textContent = opcion.textContent;
};

/**
 * Agrega un nuevo campo de participante al formulario de organización
 * y recalcula la cantidad de partidos necesarios.
 * @method agregarParticipante
 * @return {void}
 */
const agregarParticipante = () => {
  const contenedor = document.getElementById('participantes');
  const numero = contenedor.children.length + 1;

  const campo = document.createElement('div');
  campo.className = 'field';
  campo.innerHTML = `
    <label for="participante-${numero}">Participante ${numero}</label>
    <input id="participante-${numero}" name="participante-${numero}" placeholder="Nombre o equipo" maxlength="24" size="20">
  `;
  contenedor.appendChild(campo);

  calcularPartidos();
};

/**
 * Actualiza el nombre del torneo mostrado en el resumen a medida que
 * el usuario escribe en el campo correspondiente.
 * @method actualizarResumen
 * @param {Event} evento - Evento "input" del campo nombre del torneo
 * @return {void}
 */
const actualizarResumen = (evento) => {
  document.getElementById('resumen-nombre').textContent = evento.target.value || 'Sin definir';
};

/**
 * Valida que el nombre del torneo tenga al menos 3 caracteres. Si el
 * usuario escribió algo demasiado corto, avisa con un alert y
 * vacía el campo para que lo vuelva a completar.
 * @method validarNombre
 * @param {HTMLInputElement} campo - Input del nombre del torneo
 * @return {void}
 */
const validarNombre = (campo) => {
  const valor = campo.value.trim();
  if (valor.length > 0 && valor.length < 3) {
    alert('El nombre del torneo debe tener al menos 3 caracteres.');
    campo.value = '';
    document.getElementById('resumen-nombre').textContent = 'Sin definir';
  }
};

/**
 * Calcula la cantidad de partidos necesarios para llegar a un campeón
 * (participantes - 1) y actualiza el resumen del formulario.
 * @method calcularPartidos
 * @return {void}
 */
const calcularPartidos = () => {
  const cantidad = document.getElementById('participantes').children.length;
  document.getElementById('resumen-participantes').textContent = `${cantidad} cargados`;
  document.getElementById('resumen-partidos').textContent = `${Math.max(cantidad - 1, 0)} partidos`;
};

/**
 * Valida los participantes cargados, arma el fixture inicial mezclando
 * el orden al azar y muestra la primera fase de cruces del torneo.
 * @method crearTorneo
 * @param {Event} evento - Evento "submit" del formulario de organización
 * @return {void}
 */
const crearTorneo = (evento) => {
  evento.preventDefault();

  const inputs = document.querySelectorAll('#participantes input');
  let jugadores = [];
  inputs.forEach((input) => {
    if (input.value.trim() !== '') {
      jugadores.push(input.value.trim());
    }
  });

  if (jugadores.length < 2) {
    alert('Necesitás al menos 2 participantes para generar los cruces.');
    return;
  }

  jugadores = jugadores.sort(() => Math.random() - 0.5);

  document.getElementById('form-torneo').classList.add('hidden');

  const nombreTorneo = document.getElementById('nombre-torneo').value || 'Sin nombre';
  const bracket = document.createElement('div');
  bracket.id = 'bracket-view';
  bracket.className = 'form-card';
  bracket.innerHTML = `
    <div class="eyebrow">Torneo en curso</div>
    <h2 class="bracket-title">${nombreTorneo}</h2>
    <p class="page-subtitle bracket-subtitle">Jugá los partidos y registrá los ganadores para avanzar de fase.</p>
    <div id="fase-container"></div>
  `;
  document.querySelector('.page-shell').appendChild(bracket);

  mostrarFase(jugadores);
};

/**
 * Renderiza los cruces de la fase actual del torneo. Si sólo queda un
 * jugador en carrera, muestra la pantalla de campeón.
 * @method mostrarFase
 * @param {string[]} jugadores - Jugadores o equipos que siguen en carrera
 * @return {void}
 */
const mostrarFase = (jugadores) => {
  const container = document.getElementById('fase-container');
  container.innerHTML = '';

  if (jugadores.length === 1) {
    container.innerHTML = `
      <div class="champion-box">
        <div class="champion-icon">🏆</div>
        <h2 class="champion-title">¡Campeón!</h2>
        <h3 class="champion-name">${jugadores[0]}</h3>
        <button class="button primary" onclick="location.reload()">Organizar nuevo torneo</button>
      </div>
    `;
    return;
  }

  const titulo = document.createElement('h3');
  titulo.className = 'phase-title';
  titulo.textContent = jugadores.length === 2 ? 'Gran Final' : `Fase de ${jugadores.length}`;
  container.appendChild(titulo);

  const lista = document.createElement('div');
  lista.className = 'matches-list';

  for (let i = 0; i < jugadores.length; i += 2) {
    const j1 = jugadores[i];
    const j2 = jugadores[i + 1];
    const fila = document.createElement('div');
    fila.className = 'match-row';

    if (j2) {
      fila.innerHTML = `
        <div class="match-players">
          <span>${j1}</span>
          <span class="vs-label">VS</span>
          <span>${j2}</span>
        </div>
        <select class="ganador-select winner-select">
          <option value="">Registrar ganador...</option>
          <option value="${j1}">${j1}</option>
          <option value="${j2}">${j2}</option>
        </select>
      `;
    } else {
      fila.innerHTML = `
        <div class="match-players">${j1}</div>
        <span class="bye-tag">Pasa directo (sin rival)</span>
        <input type="hidden" class="ganador-select" value="${j1}">
      `;
    }

    lista.appendChild(fila);
  }

  container.appendChild(lista);
  container.insertAdjacentHTML(
    'beforeend',
    '<button class="button primary btn-advance" onclick="procesarResultados()">Guardar resultados y avanzar de fase</button>'
  );
};

/**
 * Junta los ganadores seleccionados en cada partido de la fase actual
 * y avanza a la siguiente ronda. Si falta cargar algún resultado,
 * avisa al usuario con un alert.
 * @method procesarResultados
 * @return {void}
 */
const procesarResultados = () => {
  const selects = document.querySelectorAll('.ganador-select');
  const ganadores = [];
  let faltanResultados = false;

  selects.forEach((select) => {
    if (!select.value) {
      faltanResultados = true;
    } else {
      ganadores.push(select.value);
    }
  });

  if (faltanResultados) {
    alert('Por favor, seleccioná al ganador de todos los partidos antes de avanzar.');
    return;
  }

  mostrarFase(ganadores);
};
